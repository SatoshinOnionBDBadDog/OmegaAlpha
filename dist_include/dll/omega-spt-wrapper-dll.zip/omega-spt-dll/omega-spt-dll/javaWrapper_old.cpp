#include <jni.h>
#include <stdio.h>

#include "javaWrapper.h"
#include "LibraryRunner.h"
#include "LibraryDataReaderAPI.h"
#include "LibraryDataWriterAPI.h"

void* runner;

// Set LinkRange
//setParameter(runner, "p4", "1");
// Set Radius
//setParameter(runner, "p0", "1");
// Set Images Num
//setParameter(runner, "p5", "41");
// Set Image Width
//setParameter(runner, "p6", "512");
// Set Image Height
//setParameter(runner, "p7", "512");
// Set Image Min
//setParameter(runner, "p8", "0.");
// Set Image Max
//setParameter(runner, "p9", "65535.");


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_initRunnner(JNIEnv *env, jobject obj)
{
	runner = initRunner();
}

JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_setParameter(JNIEnv *env, jobject obj, jstring pNum, jstring pValue)
{
	const char *num;
	const char *val;

	num = env->GetStringUTFChars(pNum,   0);
	val = env->GetStringUTFChars(pValue, 0);

	printf("%s %s\n", num, val);
    setParameter(runner, (char *)num, (char *)val);

	env->ReleaseStringUTFChars(pNum, num);
	env->ReleaseStringUTFChars(pValue, val);
}

JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_startRunnner(JNIEnv *env, jobject obj)
{
	startRunner(runner);
}

static __inline void writeTrajectory(FILE* file, track* trk, unsigned int id) 
{
	int i;
	fprintf(file, "%% Trajectory id: %d\n", id);
	for (i = 0; i < trk->npoints; i++)
		fprintf(file, "%d %f %f\n", trk->frameNo[i], trk->x[i], trk->y[i]);
	fprintf(file, "\n");
}

JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_loadImage(JNIEnv *env, jobject obj, jintArray data)
{
	image* img;
	FILE* outFile;
	int cnt = 0;
	track* trk = NULL;

	img = getInputDataPtr(runner);

	//outFile = fopen("a.dat", "w");
	//fprintf(outFile, "before copy\n");
	//fclose(outFile);

	int len = env->GetArrayLength(data);
	
	//outFile = fopen("a.dat", "a");
	//fprintf(outFile, "java int array length %d\n", len);
	//fclose(outFile);

	//int *d = new int[len];


	env->GetIntArrayRegion(data, 0, len, (jint *)img->imgData);
	
//	for(int i=0; i < 512*512; i++)
	//for(int i=0; i < len; i++)
	//{
	//	img->imgData[i] = d[i];
	//}

	//outFile = fopen("a.dat", "a");
	//fprintf(outFile, "after copy\n");
	//fclose(outFile);

	setInputData(runner, img);

	//outFile = fopen("a.dat", "a");
	//fprintf(outFile, "after set input data\n");
	//fclose(outFile);

	//while (isExecuting(runner) || hasOutputData(runner)) 
	//{
	//	outFile = fopen("a.dat", "a");
	//	fprintf(outFile, "inside while\n");
	//	fclose(outFile);

	if (hasOutputData(runner)) 
	{
			//outFile = fopen("a.dat", "a");
			//fprintf(outFile, "inside if\n");
			//fclose(outFile);

		trk = getOutputData(runner);

			//outFile = fopen("a.dat", "a");
			//fprintf(outFile, "before write track\n");
			//fclose(outFile);

		outFile = fopen("a.dat", "a");
		writeTrajectory(outFile, trk, cnt);
		fclose(outFile);

			//outFile = fopen("a.dat", "a");
			//fprintf(outFile, "after write track\n");			
			//fclose(outFile);

		releaseOutputData(runner, trk);
		cnt++;
	}
//}
}

JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_disposeRunner(JNIEnv *env, jobject obj)
{
	stopRunner(runner);
	disposeRunner(runner);
}