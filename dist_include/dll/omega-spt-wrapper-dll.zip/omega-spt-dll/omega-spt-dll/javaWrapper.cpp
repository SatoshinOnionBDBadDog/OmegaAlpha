#include <jni.h>
#include <stdio.h>

#include "javaWrapper.h"
#include "LibraryRunner.h"
#include "LibraryDataReaderAPI.h"
#include "LibraryDataWriterAPI.h"

char outputPath[2048];
void* runner;
int minPoints;


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_setOutputPath(JNIEnv *env, jobject obj, jstring path)
{
	env->GetStringUTFRegion(path, 0, env->GetStringLength(path), outputPath);
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_initRunnner(JNIEnv *env, jobject obj)
{
	runner = initRunner();
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_setParameter(JNIEnv *env, jobject obj, jstring pNum, jstring pValue)
{
	const char *num;
	const char *val;

	num = env->GetStringUTFChars(pNum,   0);
	val = env->GetStringUTFChars(pValue, 0);

    setParameter(runner, (char *)num, (char *)val);

	env->ReleaseStringUTFChars(pNum, num);
	env->ReleaseStringUTFChars(pValue, val);
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_setMinPoints(JNIEnv *env, jobject obj, jint num)
{
	minPoints = (int) num;
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_startRunnner(JNIEnv *env, jobject obj)
{
	startRunner(runner);
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_loadImage(JNIEnv *env, jobject obj, jintArray data)
{
	image* img;
	
	img = getInputDataPtr(runner);

	int len = env->GetArrayLength(data);
	env->GetIntArrayRegion(data, 0, len, (jint *)img->imgData);
	
	setInputData(runner, img);
}


static __inline void writeTrajectory(track* trk, unsigned int id) 
{      
	if(trk->npoints > minPoints)
	{
		int i;
		FILE* outFile;
		char  outFileName[2048];

		sprintf(outFileName, "%s\\trj_%u.out", outputPath, id);
      
		outFile = fopen(outFileName, "w");
      
		for (i = 0; i < trk->npoints; i++)
		{
			//fprintf(outFile, "%d %f %f\n", trk->frameNo[i]+1, trk->x[i], trk->y[i]);
			
			// before 2012-12-18 (without intensity)
			//fprintf(outFile, "%d %f %f %f %f %f %f %f %f %f\n", trk->frameNo[i]+1, trk->x[i], trk->y[i], trk->peakSignal[i], trk->meanSignal[i], trk->meanBackground[i], trk->meanNoise[i], trk->snr[i], trk->m0[i], trk->m2[i]);
		
			// as 2012-12-18
			fprintf(outFile, "%d %f %f %f %f %f %f %f %f %f %f %d\n", trk->frameNo[i]+1, trk->x[i], trk->y[i], trk->peakSignal[i], trk->meanSignal[i], trk->meanBackground[i], trk->meanNoise[i], trk->snr[i], trk->m0[i], trk->m2[i], trk->totalSignal[i], trk->cntSignal[i]);
		}

		fprintf(outFile, "\n");
		fclose(outFile);
	}
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_writeResults(JNIEnv *env, jobject obj)
{
	int cnt = 0;
	track* trk = NULL;
	//FILE* outFile; 

	while(isExecuting(runner) || hasOutputData(runner))
	{
		if (hasOutputData(runner)) 
		{
			trk = getOutputData(runner);

			writeTrajectory(trk, cnt);
			
			//outFile = fopen("a.out", "a");
			//writeTrajectory(outFile, trk, cnt);
			//fclose(outFile);

			releaseOutputData(runner, trk);
			cnt++;
		}
	}
}


JNIEXPORT void JNICALL Java_ch_supsi_omega_dll_SPTCaller_disposeRunner(JNIEnv *env, jobject obj)
{
	stopRunner(runner);
	disposeRunner(runner);
}