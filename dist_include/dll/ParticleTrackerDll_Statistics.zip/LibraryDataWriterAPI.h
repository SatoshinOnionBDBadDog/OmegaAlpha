/*
 * LibraryDataWriterAPI.h
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#ifndef LIBRARY_DATA_WRITER_API_H_
#define LIBRARY_DATA_WRITER_API_H_

typedef struct track track;
typedef struct trackStruct trackStruct;

struct track {
	char *filename;
	int npoints;
	int *frameNo;
	double *x;
	double *y;
	double *totalSignal;
	int *cntSignal;
	double *peakSignal;
	double *meanSignal;
	double *meanBackground;
	double *meanNoise;
	double *snr;
	double *m0;
	double *m2;
	int *labels;

	track* next;
	int maxSize;
};

struct trackStruct {
    int flagFiltered;
    int ntrack;
    track **tracks;
};

/*
 * When building the DLL code, you should define DLL_BUILD so that
 * the variables/functions are exported correctly. When using the DLL,
 * do NOT define DLL_BUILD, and then the variables/functions will
 * be imported correctly.
 */
#define DLL_BUILD

# ifdef DLL_BUILD
#    define DLLPORT __declspec (dllexport)
#  else
#    define DLLPORT __declspec (dllimport)
#  endif

#ifdef __cplusplus
extern "C" {
#endif

DLLPORT int hasOutputData(void* runner);

DLLPORT track* getOutputData(void* runner);

DLLPORT void releaseOutputData(void* runner, track* outputData);

DLLPORT void copyOutputData(track* dst, track* src);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* LIBRARY_DATA_WRITER_API_H_ */
